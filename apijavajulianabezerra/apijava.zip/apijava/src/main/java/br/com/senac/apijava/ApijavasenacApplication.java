package br.com.senac.apijava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApijavasenacApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApijavasenacApplication.class, args);
	}

}
